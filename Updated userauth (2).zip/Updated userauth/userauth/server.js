const express = require("express");
const app = express();
const bcrypt = require("bcrypt");
const passport = require("passport");
const flash = require("express-flash");
const session = require("express-session");
const initializePassport = require("./passport-config");

if (process.env.NODE_ENV !== "production") {
    require("dotenv").config();
}

initializePassport(
    passport,
    email => users.find(user => user.email === email),
    id => users.find(user => user.id === id)
);

const users = [];
const inventory = [];
const catalog = []; // Add this line

// Middleware setup
app.use(express.urlencoded({ extended: false }));
app.use(flash());
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());

app.set('view engine', 'ejs');
app.use(express.static('public')); // Serve static files like CSS

// Routes
app.get('/', (req, res) => {
    if (req.isAuthenticated()) {
        res.redirect('/dashboard');
    } else {
        res.render("index.ejs", { name: null });
    }
});

app.get('/login', checkNotAuthenticated, (req, res) => {
    let messages = {};
    if (req.flash('error').length) {
        messages.error = req.flash('error')[0];
    }
    res.render("login.ejs", { messages: messages });
});

app.get('/register', checkNotAuthenticated, (req, res) => {
    let messages = {};
    if (req.flash('error').length) {
        messages.error = req.flash('error')[0];
    }
    res.render("register.ejs", { messages: messages });
});

app.get('/dashboard', checkAuthenticated, (req, res) => {
    res.render('dashboard.ejs', { user: req.user });
});

app.get('/inventory', checkAuthenticated, (req, res) => {
    res.render('inventory.ejs', { inventory: inventory });
});

app.post('/inventory', checkAuthenticated, (req, res) => {
    const { seedType, quantity } = req.body;
    inventory.push({ seedType, quantity });
    res.redirect('/inventory');
});

app.get('/catalog', checkAuthenticated, (req, res) => {
    res.render('catalog.ejs', { catalog: catalog });
});

app.post('/catalog', checkAuthenticated, (req, res) => {
    const { itemName, quantity, imageUrl } = req.body;
    catalog.push({ id: Date.now().toString(), itemName, quantity, imageUrl });
    res.redirect('/catalog');
});

app.post('/catalog/delete/:id', checkAuthenticated, (req, res) => {
    const { id } = req.params;
    const index = catalog.findIndex(item => item.id === id);
    if (index > -1) {
        catalog.splice(index, 1);
    }
    res.redirect('/catalog');
});

app.post("/login", passport.authenticate("local", {
    successRedirect: "/dashboard",
    failureRedirect: "/login",
    failureFlash: true
}));

app.get('/logout', (req, res) => {
    req.logout(err => {
        if (err) {
            console.error(err);
            return next(err);
        }
        res.redirect('/');
    });
});

app.post("/register", async (req, res) => {
    try {
        const hashedPassword = await bcrypt.hash(req.body.password, 10);
        users.push({
            id: Date.now().toString(),
            name: req.body.name,
            email: req.body.email,
            password: hashedPassword,
        });
        console.log(users);
        res.redirect("/login");
    } catch (e) {
        console.log(e);
        req.flash('error', 'Registration error');
        res.redirect("/register");
    }
});

// Middleware to protect routes
function checkAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    res.redirect('/login');
}

function checkNotAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return res.redirect('/dashboard');
    }
    next();
}

// Remaining routes for profile, settings, and rooms
app.get('/profile', checkAuthenticated, (req, res) => {
    res.render('profile', { user: req.user });
});

app.get('/settings', checkAuthenticated, (req, res) => {
    res.render('settings', { user: req.user });
});

app.get('/rooms', checkAuthenticated, (req, res) => {
    res.render('rooms', { user: req.user });
});

app.listen(3000, () => {
    console.log('server is running on port 3000');
});
